module.exports = {
  BOT_TOKEN:
  "7768033037:AAGZEVOtl6pWJq9jGcIgyLlE7bHMjXXBeo0",
};